const { ipcRenderer } = require('electron');

document.getElementById('studio-button').addEventListener('click', () => {
    ipcRenderer.send('open-studio'); // Send a request to open the studio
});





document.getElementById('home-btn').addEventListener('click', () => {
    document.getElementById('streaming-section').style.display = 'block';
    document.getElementById('production-section').style.display = 'none';
});

document.getElementById('create-btn').addEventListener('click', () => {
    document.getElementById('streaming-section').style.display = 'none';
    document.getElementById('production-section').style.display = 'block';
});


const playPauseButton = document.getElementById('play-pause-button');
const prevButton = document.getElementById('prev-button');
const nextButton = document.getElementById('next-button');
const seekBar = document.getElementById('seek-bar');
const currentTimeDisplay = document.getElementById('current-time');
const totalTimeDisplay = document.getElementById('total-time');
const trackTitle = document.getElementById('track-title');

// Music Player Logic
let audio = new Audio(); // Audio object
let isPlaying = false;
let trackIndex = 0;

// Sample playlist
const playlist = [
    { title: "Track 1", src: "path/to/track1.mp3" },
    { title: "Track 2", src: "path/to/track2.mp3" },
    { title: "Track 3", src: "path/to/track3.mp3" },
];

// Load the first track
function loadTrack(index) {
    audio.src = playlist[index].src;
    trackTitle.textContent = playlist[index].title;
    audio.load();
}

// Update time display
function updateTime() {
    const currentTime = Math.floor(audio.currentTime);
    const totalTime = Math.floor(audio.duration);
    currentTimeDisplay.textContent = formatTime(currentTime);
    totalTimeDisplay.textContent = formatTime(totalTime);
    seekBar.value = (audio.currentTime / audio.duration) * 100 || 0;
}

// Format time in MM:SS
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs < 10 ? "0" : ""}${secs}`;
}

// Event Listeners
playPauseButton.addEventListener('click', () => {
    if (isPlaying) {
        audio.pause();
        playPauseButton.textContent = "▶";
    } else {
        audio.play();
        playPauseButton.textContent = "⏸";
    }
    isPlaying = !isPlaying;
});

prevButton.addEventListener('click', () => {
    trackIndex = (trackIndex - 1 + playlist.length) % playlist.length;
    loadTrack(trackIndex);
    audio.play();
    isPlaying = true;
    playPauseButton.textContent = "⏸";
});

nextButton.addEventListener('click', () => {
    trackIndex = (trackIndex + 1) % playlist.length;
    loadTrack(trackIndex);
    audio.play();
    isPlaying = true;
    playPauseButton.textContent = "⏸";
});

seekBar.addEventListener('input', () => {
    audio.currentTime = (seekBar.value / 100) * audio.duration;
});

// Update time continuously
audio.addEventListener('timeupdate', updateTime);
audio.addEventListener('loadedmetadata', updateTime);

// Initialize the player
loadTrack(trackIndex);




