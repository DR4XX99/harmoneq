const { app, BrowserWindow, ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');
const axios = require('axios'); // Import axios

let splashWindow;
let mainWindow;
let studioWindow = null;

const musicFolderPath = path.join(__dirname, 'music'); // Path to the music folder

app.on('ready', () => {
    console.log('App is ready');

    // Splash Screen
    splashWindow = new BrowserWindow({
        width: 400,
        height: 300,
        frame: false,
        alwaysOnTop: true,
        transparent: true,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
        },
    });

    splashWindow.loadFile('splash.html')
        .then(() => console.log('Splash screen loaded'))
        .catch(err => console.error('Error loading splash screen:', err));

    // Main Window
    mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
        show: false, // Hide initially
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
        },
    });

    mainWindow.loadFile('demo.html')
        .then(() => {
            console.log('Main window loaded');
            setTimeout(() => {
                splashWindow.close();
                mainWindow.show();

                // Fetch tracks from API after main window is shown
                axios.get('http://127.0.0.1:8000/api/tracks/')
                    .then(response => console.log(response.data))
                    .catch(error => console.error(error));
            }, 2000); // Show main window after 2 seconds
        })
        .catch(err => console.error('Error loading main window:', err));

    // Handle request for loading tracks from a text file
    ipcMain.on('load-tracks', (event) => {
        const tracksFilePath = path.join(__dirname, 'tracks.txt'); // Path to the tracks.txt file
        fs.readFile(tracksFilePath, 'utf-8', (err, data) => {
            if (err) {
                console.error('Error reading tracks file:', err);
                event.reply('tracks-response', { success: false, error: err.message });
                return;
            }

            // Split the file contents into an array of track names
            const trackNames = data.split('\n').map(track => track.trim());
            
            // Send the track names to the renderer process (front-end)
            event.reply('tracks-response', { success: true, tracks: trackNames });
        });
    });

    // Handle request for loading music files from the music folder
    ipcMain.on('load-music-files', (event) => {
        fs.readdir(musicFolderPath, (err, files) => {
            if (err) {
                console.error('Error reading music folder:', err);
                event.reply('music-files-response', { success: false, error: err.message });
                return;
            }

            // Filter for audio files (you can add more extensions as needed)
            const audioFiles = files.filter(file => file.endsWith('.mp3') || file.endsWith('.wav'));
            event.reply('music-files-response', { success: true, files: audioFiles });
        });
    });

    // Handle studio window creation
    ipcMain.on('open-studio', () => {
        if (!studioWindow) {
            try {
                studioWindow = new BrowserWindow({
                    width: 800,
                    height: 600,
                    webPreferences: {
                        nodeIntegration: true,
                        contextIsolation: false,
                    },
                });

                studioWindow.loadFile('studio.html')
                    .then(() => console.log('Studio window loaded'))
                    .catch(err => console.error('Error loading studio window:', err));

                studioWindow.on('closed', () => {
                    studioWindow = null; // Clean up reference
                });
            } catch (error) {
                console.error('Error creating studio window:', error);
            }
        } else {
            studioWindow.focus(); // Bring existing window to focus
        }
    });

    // Handle opening the music player
    ipcMain.on('open-music-player', () => {
        const musicPlayerWindow = new BrowserWindow({
            width: 800,
            height: 600,
            webPreferences: {
                nodeIntegration: true,
                contextIsolation: false,
            },
        });

        musicPlayerWindow.loadFile('music-player.html')
            .then(() => console.log('Music player window loaded'))
            .catch(err => console.error('Error loading music player window:', err));
    });

    app.on('window-all-closed', () => {
        if (process.platform !== 'darwin') {
            app.quit(); // Quit app if not on macOS
        }
    });
});
